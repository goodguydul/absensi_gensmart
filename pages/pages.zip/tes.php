<?php
date_default_timezone_set('Asia/Jakarta');
$date = date('H.i ', time());
echo $date;
?>