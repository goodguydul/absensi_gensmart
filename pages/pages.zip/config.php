<?php
$servername = "localhost";
$username 	= "admin_gensmart";
$password 	= "gensmartdb!";
$database	= "admin_gensmart";

// Create connection
$conn = new mysqli($servername, $username, $password,$database);


?> 